"""ingest_data.py

Skrip Data Ingestion otomatis untuk proyek gold-price-mlops (LK-04).

Mengambil data harga emas (ticker GC=F, Gold Continuous Contract, COMEX)
dari Yahoo Finance API menggunakan pustaka yfinance -- sumber data yang
telah ditentukan dan dijustifikasi pada LK-03 BAB I. Skrip ini
mengimplementasikan tiga prinsip dari modul "Teknik Data Acquisition":

1. Non-destructive ingestion: setiap eksekusi menghasilkan berkas CSV
   baru bertimestamp di data/raw/, tidak pernah menimpa data lama.
2. Resiliensi: retry otomatis dengan exponential backoff saat terjadi
   gangguan koneksi ke API eksternal (lihat LK-03 BAB II.1).
3. Data lineage: setiap berkas disertai metadata (.meta.json) berisi
   source_url, waktu akses, dan jumlah baris untuk audit trail --
   dipakai sebagai dasar versioning pada LK-05 (DVC).

Cara pakai:
    python src/ingest_data.py                  Ambil update harian (30 hari terakhir)
    python src/ingest_data.py --full-history    Ambil histori ~2 tahun (dipakai SEKALI
                                                 di awal proyek agar dataset awal >= 500
                                                 baris, sesuai anjuran modul LK-04)
    python src/ingest_data.py --period 5d       Override manual rentang waktu
"""

import argparse
import json
import logging
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

try:
    import yfinance as yf
except ImportError:  # pragma: no cover - ditangani saat runtime, lihat main()
    yf = None

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger("ingest_data")

TICKER = "GC=F"
RAW_DIR = Path(__file__).resolve().parents[1] / "data" / "raw"
MAX_RETRIES = 3
BACKOFF_BASE_SECONDS = 2


def fetch_market_data(period: str = "1mo", interval: str = "1d") -> pd.DataFrame:
    """Mengambil data harga emas dari Yahoo Finance dengan retry otomatis.

    Args:
        period: rentang waktu data yang diambil oleh yfinance (mis. "1mo", "2y").
        interval: granularitas data, default harian ("1d").

    Returns:
        DataFrame OHLCV mentah dengan kolom "Ticker" ditambahkan.

    Raises:
        RuntimeError: jika seluruh percobaan retry (MAX_RETRIES kali) gagal.
        ImportError: jika pustaka yfinance belum terinstal.
    """
    if yf is None:
        raise ImportError(
            "Pustaka 'yfinance' belum terinstal. Jalankan: pip install yfinance"
        )

    last_error = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            logger.info(
                "Percobaan %s/%s: mengambil data %s (period=%s, interval=%s)",
                attempt, MAX_RETRIES, TICKER, period, interval,
            )
            data = yf.download(
                TICKER,
                period=period,
                interval=interval,
                progress=False,
                auto_adjust=False,
            )
            if data is None or data.empty:
                raise ValueError("API mengembalikan data kosong")

            data = data.reset_index()
            # yfinance versi terbaru dapat mengembalikan kolom MultiIndex
            if isinstance(data.columns, pd.MultiIndex):
                data.columns = [c[0] for c in data.columns]
            data["Ticker"] = TICKER

            logger.info("Berhasil mengambil %s baris data mentah", len(data))
            return data

        except Exception as exc:  # noqa: BLE001 - tangkap semua error jaringan/API
            last_error = exc
            wait = BACKOFF_BASE_SECONDS ** attempt
            logger.warning(
                "Percobaan %s gagal (%s). Mencoba lagi dalam %ss...",
                attempt, exc, wait,
            )
            if attempt < MAX_RETRIES:
                time.sleep(wait)

    raise RuntimeError(
        f"Gagal mengambil data setelah {MAX_RETRIES} percobaan. Error terakhir: {last_error}"
    )


def save_raw_data(df: pd.DataFrame, source_period: str) -> Path:
    """Menyimpan data mentah secara non-destruktif (append-only, bertimestamp).

    Setiap eksekusi menghasilkan file CSV baru dengan nama unik berbasis
    timestamp saat ini, sehingga data hasil ingestion sebelumnya tidak
    pernah tertimpa (lihat LK-03 BAB II.1 dan modul "Non-Destructive
    Ingestion"). Sebuah berkas metadata pendamping (.meta.json) turut
    disimpan untuk keperluan data lineage / audit trail.
    """
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"gold_raw_{ts}.csv"
    filepath = RAW_DIR / filename
    df.to_csv(filepath, index=False)

    metadata = {
        "source_url": "https://query1.finance.yahoo.com (diakses via pustaka yfinance)",
        "ticker": TICKER,
        "accessed_at": datetime.now(timezone.utc).isoformat(),
        "period_requested": source_period,
        "record_count": len(df),
        "output_file": filename,
    }
    meta_path = RAW_DIR / f"{filename}.meta.json"
    meta_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    logger.info("Data mentah disimpan -> %s (%s baris)", filepath, len(df))
    logger.info("Metadata lineage disimpan -> %s", meta_path)
    return filepath


def main():
    parser = argparse.ArgumentParser(
        description="Ingestion data harga emas GC=F secara otomatis dari Yahoo Finance API"
    )
    parser.add_argument(
        "--full-history",
        action="store_true",
        help=(
            "Ambil histori panjang (~2 tahun) untuk membangun baseline dataset awal. "
            "Dipakai SEKALI di awal proyek agar volume data >= 500 baris, sesuai "
            "anjuran modul LK-04 untuk persiapan DVC di LK-05."
        ),
    )
    parser.add_argument(
        "--period",
        default=None,
        help="Override manual rentang waktu yfinance (mis. '5d', '1mo', '2y').",
    )
    args = parser.parse_args()

    if args.period:
        period = args.period
    elif args.full_history:
        period = "2y"
    else:
        period = "1mo"

    try:
        df = fetch_market_data(period=period)
    except Exception as exc:  # noqa: BLE001
        logger.error("Ingestion gagal total: %s", exc)
        sys.exit(1)

    save_raw_data(df, source_period=period)
    logger.info("=== INGESTION SELESAI ===")


if __name__ == "__main__":
    main()
