"""preprocess.py

Skrip prapemrosesan (cleaning) data mentah harga emas untuk proyek
gold-price-mlops (LK-04).

Membaca berkas mentah hasil src/ingest_data.py dari data/raw/, melakukan
pembersihan data (validasi skema, penanganan missing values, deduplikasi,
konversi satuan), lalu menyimpan hasilnya ke data/processed/ sebagai satu
berkas bertimestamp yang siap dipakai pada tahap ekstraksi fitur
berikutnya (lihat LK-03 BAB II.2 dan II.3).

Karena data proyek ini bersifat numerik/time-series (bukan teks), jalur
pembersihan yang dipakai adalah "pembersihan missing values" sesuai
opsi pada instruksi LK-04 -- bukan tokenization/stopword removal yang
ditujukan untuk domain NLP.

Cara pakai:
    python src/preprocess.py            Proses berkas raw TERBARU saja
    python src/preprocess.py --all      Gabungkan & proses SEMUA berkas raw
"""

import argparse
import glob
import logging
from datetime import datetime
from pathlib import Path

import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger("preprocess")

BASE_DIR = Path(__file__).resolve().parents[1]
RAW_DIR = BASE_DIR / "data" / "raw"
PROCESSED_DIR = BASE_DIR / "data" / "processed"

REQUIRED_COLUMNS = ["Date", "Open", "High", "Low", "Close", "Volume", "Ticker"]
TROY_OUNCE_TO_GRAM = 31.1034768
OUTLIER_THRESHOLD_PCT = 0.15  # 15%, lihat LK-03 BAB II.2 (potensi geopolitical drift)


def load_raw_files(use_all: bool = False) -> pd.DataFrame:
    """Memuat satu (terbaru) atau seluruh berkas CSV mentah pada data/raw/."""
    files = sorted(glob.glob(str(RAW_DIR / "gold_raw_*.csv")))
    if not files:
        raise FileNotFoundError(
            f"Tidak ada berkas data mentah ditemukan di {RAW_DIR}. "
            "Jalankan 'python src/ingest_data.py' terlebih dahulu."
        )

    target_files = files if use_all else [files[-1]]
    logger.info(
        "Memuat %s berkas mentah: %s",
        len(target_files), [Path(f).name for f in target_files],
    )

    frames = [pd.read_csv(f) for f in target_files]
    df = pd.concat(frames, ignore_index=True)
    logger.info("Total baris sebelum cleaning: %s", len(df))
    return df


def validate_schema(df: pd.DataFrame) -> pd.DataFrame:
    """Memvalidasi keberadaan kolom wajib dan tipe data kolom tanggal."""
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Skema data tidak lengkap, kolom hilang: {missing}")
    df["Date"] = pd.to_datetime(df["Date"])
    return df


def remove_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """Menghapus baris dengan tanggal duplikat akibat ingestion berulang."""
    before = len(df)
    df = df.sort_values("Date").drop_duplicates(subset="Date", keep="last")
    df = df.reset_index(drop=True)
    logger.info("Duplikat dihapus: %s baris", before - len(df))
    return df


def clean_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """Menangani nilai kosong (mis. hari libur bursa) dengan forward-fill."""
    price_cols = ["Open", "High", "Low", "Close"]
    n_missing_before = int(df[price_cols].isna().sum().sum())
    df[price_cols] = df[price_cols].ffill()
    n_missing_after = int(df[price_cols].isna().sum().sum())
    logger.info(
        "Missing values pada kolom harga: %s -> %s (forward-fill hari non-trading)",
        n_missing_before, n_missing_after,
    )
    return df


def convert_units(df: pd.DataFrame) -> pd.DataFrame:
    """Konversi harga dari USD/troy-ounce ke USD/gram (lihat LK-03 BAB II.2)."""
    df["Close_USD_per_gram"] = df["Close"] / TROY_OUNCE_TO_GRAM
    return df


def flag_outliers(df: pd.DataFrame) -> pd.DataFrame:
    """Menandai (BUKAN menghapus) lonjakan harga >15% sebagai potensi drift.

    Nilai ekstrem sengaja tidak dibuang karena berpotensi menjadi sinyal
    geopolitical drift yang sah (LK-01 BAB II), bukan derau/noise.
    """
    df["pct_change"] = df["Close_USD_per_gram"].pct_change()
    df["is_outlier_flag"] = df["pct_change"].abs() > OUTLIER_THRESHOLD_PCT
    n_flagged = int(df["is_outlier_flag"].sum())
    if n_flagged:
        logger.warning(
            "%s baris ditandai sebagai potensi lonjakan ekstrem (>15%%), "
            "tidak dihapus", n_flagged,
        )
    return df


def save_processed(df: pd.DataFrame) -> Path:
    """Menyimpan data bersih ke data/processed/, siap untuk ekstraksi fitur."""
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath = PROCESSED_DIR / f"gold_clean_{ts}.csv"
    df.to_csv(filepath, index=False)
    logger.info(
        "Data bersih disimpan -> %s (%s baris, siap masuk ke tahap ekstraksi fitur)",
        filepath, len(df),
    )
    return filepath


def main():
    parser = argparse.ArgumentParser(
        description="Preprocessing/cleaning data mentah harga emas GC=F"
    )
    parser.add_argument(
        "--all", action="store_true",
        help="Gabungkan seluruh berkas raw yang ada, bukan hanya yang terbaru",
    )
    args = parser.parse_args()

    df = load_raw_files(use_all=args.all)
    df = validate_schema(df)
    df = remove_duplicates(df)
    df = clean_missing_values(df)
    df = convert_units(df)
    df = flag_outliers(df)

    save_processed(df)
    logger.info("=== PREPROCESSING SELESAI ===")


if __name__ == "__main__":
    main()
