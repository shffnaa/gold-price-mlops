"""Unit test ringan untuk memverifikasi logika retry & error handling pada
src/ingest_data.py, tanpa memerlukan koneksi internet nyata ke Yahoo Finance.
"""
import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import ingest_data  # noqa: E402


def test_retry_then_success():
    """Simulasikan 2x gagal (network error), lalu berhasil di percobaan ke-3."""
    import pandas as pd

    call_count = {"n": 0}

    def flaky_download(*args, **kwargs):
        call_count["n"] += 1
        if call_count["n"] < 3:
            raise ConnectionError("Simulasi gangguan jaringan")
        return pd.DataFrame({
            "Open": [100.0], "High": [101.0], "Low": [99.0],
            "Close": [100.5], "Adj Close": [100.5], "Volume": [1000],
        }, index=pd.to_datetime(["2026-09-26"]))

    with patch("ingest_data.yf.download", side_effect=flaky_download), \
         patch("ingest_data.time.sleep", return_value=None):  # percepat test
        df = ingest_data.fetch_market_data(period="5d")

    assert call_count["n"] == 3, f"Harusnya 3 percobaan, dapat {call_count['n']}"
    assert len(df) == 1
    assert df["Ticker"].iloc[0] == "GC=F"
    print("PASS: retry berhasil pulih setelah 2x gagal, di percobaan ke-3")


def test_all_retries_fail():
    """Simulasikan API selalu gagal -> harus raise RuntimeError setelah 3x percobaan."""
    def always_fail(*args, **kwargs):
        raise ConnectionError("API down")

    with patch("ingest_data.yf.download", side_effect=always_fail), \
         patch("ingest_data.time.sleep", return_value=None):
        try:
            ingest_data.fetch_market_data(period="5d")
            raise AssertionError("Harusnya raise RuntimeError, tapi tidak")
        except RuntimeError as e:
            assert "3 percobaan" in str(e)
            print(f"PASS: gagal total setelah retry ditangani dengan benar -> {e}")


if __name__ == "__main__":
    test_retry_then_success()
    test_all_retries_fail()
    print("\n=== SEMUA TEST LOGIKA RETRY LULUS ===")
