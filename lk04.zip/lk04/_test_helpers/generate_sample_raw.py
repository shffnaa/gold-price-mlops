"""Generator data sampel (offline) untuk MENGUJI src/preprocess.py secara lokal,
karena sandbox pengembangan ini tidak memiliki akses jaringan ke Yahoo Finance.

INI BUKAN bagian dari deliverable LK-04 -- src/ingest_data.py yang sesungguhnya
akan menggantikan skrip ini dengan panggilan API yfinance yang nyata saat
dijalankan di GitHub Codespaces (yang punya akses internet).
"""
import numpy as np
import pandas as pd
from datetime import datetime

np.random.seed(42)

dates = pd.bdate_range(end=datetime(2026, 9, 26), periods=620)  # hari kerja bursa saja
n_days = len(dates)  # > 500 baris sesuai anjuran modul LK-04

# Random walk realistis di sekitar level harga yang dipakai LK-01/LK-03 (~USD 4300-4700/oz)
returns = np.random.normal(loc=0.0003, scale=0.012, size=n_days)
close = 4300 * np.exp(np.cumsum(returns))

open_ = close * (1 + np.random.normal(0, 0.003, n_days))
high = np.maximum(open_, close) * (1 + np.abs(np.random.normal(0, 0.004, n_days)))
low = np.minimum(open_, close) * (1 - np.abs(np.random.normal(0, 0.004, n_days)))
volume = np.random.randint(300, 200000, n_days)

df = pd.DataFrame({
    "Date": dates,
    "Open": open_.round(6),
    "High": high.round(6),
    "Low": low.round(6),
    "Close": close.round(6),
    "Adj Close": close.round(6),
    "Volume": volume,
})
df["Ticker"] = "GC=F"

# Suntikkan beberapa baris kosong & duplikat untuk menguji logika cleaning
df.loc[10, ["Open", "High", "Low", "Close"]] = np.nan
df.loc[250, ["Open", "High", "Low", "Close"]] = np.nan
dup_row = df.loc[[100]].copy()
df = pd.concat([df, dup_row], ignore_index=True)

out_path = "/home/claude/lk04/data/raw/gold_raw_20260926_050000.csv"
df.to_csv(out_path, index=False)
print(f"Sample raw data disimpan: {out_path} ({len(df)} baris, termasuk simulasi missing+duplikat)")
